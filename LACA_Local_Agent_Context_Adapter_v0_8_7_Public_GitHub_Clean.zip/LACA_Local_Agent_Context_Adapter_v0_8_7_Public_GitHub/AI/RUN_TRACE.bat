@echo off
cd /d "%~dp0\.."
py AI\run.py trace
if errorlevel 1 python AI\run.py trace

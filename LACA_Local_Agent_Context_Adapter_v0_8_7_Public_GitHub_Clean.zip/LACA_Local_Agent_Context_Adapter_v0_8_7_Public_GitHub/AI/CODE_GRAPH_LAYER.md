# LACA Code Graph Layer v0.8.3

This layer turns LACA from a file pre-selector into a lightweight code-map system for AI coding agents.

## What it exports

- `AI_OUT/code_graph.json` — nodes and edges for files, symbols, imports, calls, and inheritance.
- `AI_OUT/code_symbols.tsv` — functions, classes, methods, paths, and line numbers.
- `AI_OUT/import_edges.tsv` — import/include/dependency edges.
- `AI_OUT/call_edges.tsv` — call-name edges.
- `AI_OUT/inherit_edges.tsv` — inheritance/extends/base-class edges.
- `AI_OUT/graph_edges.tsv` — combined edge table.
- `AI_OUT/query_explain.md` — query results when `--query` is used.
- `AI_OUT/path_explain.md` — short path explanation when `--path-from` and `--path-to` are used.
- `AI_OUT/graph.html` — local searchable HTML viewer.
- `AI_OUT/compiler_probe_report.md` — optional syntax/compile probe report.
- `AI_STATE/code_graph_cache.json` — incremental graph cache by file hash.

## Supported parsing

- Python: real `ast` parser from the standard library.
- JavaScript/TypeScript/C/C++/Go/Rust/Java/C#/PHP/Ruby: dependency-free public regex fallback for symbols/imports/calls where possible.
- Tree-sitter: optional detection hook. The public drop-in package stays dependency-free; if tree-sitter packages are available, the status is reported, but Python AST and fallback parsers remain safe defaults.

## Commands

```bat
py AI\run.py graph
py AI\run.py graph --full --max-files 5000
py AI\run.py graph --query "run_local_learning"
py AI\run.py graph --path-from "RUN_MARTIN" --path-to "run_local_learning"
py AI\run.py graph --compiler-probe
```

## Design rule

Do not paste the entire graph into an AI prompt. Use `attention_guide.md`, `code_attention.vmem`, `query_explain.md`, and `path_explain.md` as compact external attention maps.

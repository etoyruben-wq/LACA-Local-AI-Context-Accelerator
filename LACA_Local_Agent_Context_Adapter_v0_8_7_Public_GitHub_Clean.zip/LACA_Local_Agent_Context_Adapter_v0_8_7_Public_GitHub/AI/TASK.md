# Task for AI

Write here the current task, focus points, restrictions, and success criteria.

Keep it short. This file is guidance and safeguards, not a full project description.

Agent rule: use the project map, code graph, attention guide, and agent trace stamp before changing files.

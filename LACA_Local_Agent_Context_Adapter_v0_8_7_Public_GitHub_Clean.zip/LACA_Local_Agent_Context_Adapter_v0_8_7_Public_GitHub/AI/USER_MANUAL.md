# LACA AI Drop-In v0.8.7 — User Manual

## 1. What to do with the ZIP

Unpack the ZIP. Copy the folder named `AI` into the root of your project.

Example:

```text
MyProject/
  AI/
  src/
  README.md
```

## 2. First command in chat

Paste this to your AI coding agent:

```text
There is an AI folder in the project root. Open it and follow the instruction inside.
```

The agent should read the instruction, read `AI/TASK.md` or `AI/ТЗ_UA.md`, and run:

```bat
py AI\run.py scan
```

## 3. Repeated entry / continue

Next time paste:

```text
There is an AI folder in the project root. There is a CONTINUE instruction. Execute it.
```

The agent should run:

```bat
py AI\run.py continue
```

## 4. Task file

Edit one of these files before the run:

```text
AI/TASK.md
AI/ТЗ_UA.md
```

Use it for short guidance and safeguards, not for a full project description.

## 5. After the agent finishes

The agent should create `RESULT.vmem` and run:

```bat
py AI\run.py result
```

This writes the Agent Trace Stamp and mistake memory so the next run does not repeat old failed actions.


## Skill Protocol / Протокол агента

This version includes a public skill protocol for AI coding agents. The user does not need to write a long explanation every time. The agent can read:

```text
AI/SKILL_PROTOCOL.md
AI/SKILL_PROTOCOL_UA.md
AI/AGENT_BOOTSTRAP.md
```

The protocol tells the agent to run `py AI\run.py continue`, read `AI_OUT`, use the task file, check mistake memory, make one focused change, and record `RESULT.vmem`.

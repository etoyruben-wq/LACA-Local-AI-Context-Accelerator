@echo off
cd /d "%~dp0"
cd ..
py AI
un.py skill
if errorlevel 1 (
  python AI
un.py skill
)
pause

# Інструкція першого запуску для AI-агента

1. Прочитай `AI/ТЗ_UA.md` або `AI/TASK.md`.
2. Виконай:

```bat
py AI\run.py scan
```

Якщо `py` не працює:

```bat
python AI\run.py scan
```

3. Прочитай:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
```

4. Виконай одну точну дію.
5. Створи `RESULT.vmem`.
6. Виконай:

```bat
py AI\run.py result
```

Це запише печатку трансформатора: дію агента, результат, зміни й помилки.

# LACA AI Drop-In v0.8.7 — мануал користувача

## 1. Що робити з ZIP

Розпакуй ZIP. Скопіюй папку `AI` у корінь свого проєкту.

Приклад:

```text
MyProject/
  AI/
  src/
  README.md
```

## 2. Перша команда в чат

Встав агенту:

```text
У папці проєкту є папка AI. В папці є інструкція. Виконай інструкцію.
```

Агент має прочитати інструкцію, прочитати `AI/ТЗ_UA.md` або `AI/TASK.md` і виконати:

```bat
py AI\run.py scan
```

## 3. Повторний вхід

Наступного разу встав:

```text
У папці проєкту є папка AI. Там є інструкція ПРОДОВЖИТИ. Виконай.
```

Агент має виконати:

```bat
py AI\run.py continue
```

## 4. Про ТЗ

Перед запуском можна редагувати:

```text
AI/ТЗ_UA.md
AI/TASK.md
```

ТЗ — це не повний опис проєкту. Це короткі інструкції, напрям і запобіжники.

## 5. Після завершення задачі

Агент має створити `RESULT.vmem` і виконати:

```bat
py AI\run.py result
```

Тоді LACA створює “печатку трансформатора”: записує дію агента, результат, зміни і помилки, щоб наступного разу агент не повторював невдалі кроки.


## Skill Protocol / Протокол агента

This version includes a public skill protocol for AI coding agents. The user does not need to write a long explanation every time. The agent can read:

```text
AI/SKILL_PROTOCOL.md
AI/SKILL_PROTOCOL_UA.md
AI/AGENT_BOOTSTRAP.md
```

The protocol tells the agent to run `py AI\run.py continue`, read `AI_OUT`, use the task file, check mistake memory, make one focused change, and record `RESULT.vmem`.

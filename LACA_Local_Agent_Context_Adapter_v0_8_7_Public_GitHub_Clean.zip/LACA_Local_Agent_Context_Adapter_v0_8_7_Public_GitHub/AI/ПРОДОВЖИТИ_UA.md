# Інструкція ПРОДОВЖИТИ для AI-агента

1. Прочитай `AI/ТЗ_UA.md` або `AI/TASK.md`.
2. Виконай:

```bat
py AI\run.py continue
```

Якщо `py` не працює:

```bat
python AI\run.py continue
```

3. Прочитай:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
```

4. Продовжуй зі збереженої карти. Не починай з нуля.
5. Якщо `mistake_report.md` містить невдалу дію, не повторюй її без зміни умов або прямої команди користувача.
6. Виконай одну точну дію.
7. Створи `RESULT.vmem`.
8. Виконай:

```bat
py AI\run.py result
```

# First-run instruction for AI agent

1. Read `AI/TASK.md` or `AI/ТЗ_UA.md`.
2. Run:

```bat
py AI\run.py scan
```

If `py` is not available, run:

```bat
python AI\run.py scan
```

3. Read:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
```

4. Do one focused action only.
5. Create `RESULT.vmem`.
6. Run:

```bat
py AI\run.py result
```

This records the Agent Trace Stamp and mistake memory.

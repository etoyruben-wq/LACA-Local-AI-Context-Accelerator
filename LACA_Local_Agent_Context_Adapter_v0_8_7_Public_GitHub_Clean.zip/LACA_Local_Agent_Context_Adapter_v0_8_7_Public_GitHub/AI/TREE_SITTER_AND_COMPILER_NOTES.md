# Tree-sitter and Compiler-Level Notes

LACA v0.8.3 closes the public code-map gap as far as a dependency-free drop-in tool can reasonably do it:

- Python uses real AST parsing.
- Other major languages have lightweight symbol/import/call extraction.
- Tree-sitter is detected when available, but not required.
- Compiler/syntax probes are optional with `--compiler-probe`.

## Important honesty note

`--compiler-probe` is not full compiler-level semantic precision. It is a lightweight syntax/compile smoke test:

- Python: `py_compile`
- C: `gcc -fsyntax-only` when available
- C++: `g++ -fsyntax-only` when available

Full compiler-level precision requires the real project build system, flags, include paths, dependencies, and target toolchain. LACA records what it can prove and reports what is skipped or blocked.

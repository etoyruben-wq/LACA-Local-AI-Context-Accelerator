# Changelog

## v0.8.7 — Public GitHub Clean

Prepared LACA for GitHub publication without the deferred multi-agent coordinator.

Added root-level GitHub files:

- `README.md`
- `INSTALL.md`
- `AGENTS.md`
- `LICENSE`
- `.gitignore`
- `RELEASE_NOTES_v0.8.7.md`
- `docs/GITHUB_DESCRIPTION.md`

Public scope clarified:

- no multi-agent parallel coordinator in this release;
- no private vector architecture guard;
- no private accelerators;
- no Android companion module;
- agent-independent project memory and Skill Protocol remain included.

## v0.8.7 — Public Skill Protocol

Added:

- public LACA Skill Protocol;
- `AI/SKILL_PROTOCOL.md`;
- `AI/SKILL_PROTOCOL_UA.md`;
- `AI/AGENT_BOOTSTRAP.md`;
- `AI/AGENT_BOOTSTRAP_UA.md`;
- generic agent skill file;
- Codex-style agent instructions;
- Antigravity skill file;
- Cursor rules file;
- `py AI\run.py skill` command;
- `AI_OUT/skill_protocol_context.md`;
- compact skill-protocol injection into `context_state.vmem` and `context_report.md`.

Purpose:

```text
LACA is an agent-independent project memory and workflow protocol.
```

## v0.8.4 — Public Agent Trace Stamp

Added:

- Agent Trace Stamp layer;
- mistake memory;
- previous-action ledger;
- `AI_STATE/agent_trace.jsonl`;
- `AI_STATE/transformer_stamp.jsonl`;
- `AI_STATE/mistake_memory.jsonl`;
- `AI_OUT/last_transformer_stamp.md`;
- `AI_OUT/agent_trace_report.md`;
- `AI_OUT/mistake_report.md`;
- `AI/AGENT_TRACE_STAMP.md`;
- `AI/RUN_TRACE.bat`;
- `py AI\run.py trace` command.

Changed:

- `py AI\run.py result` now records a stamp after saving result/change history.
- `scan`, `continue`, and `graph` inject recent stamp/mistake memory into `context_state.vmem`.
- README and manuals now describe the agent action ledger.

Core positioning:

```text
Graph tools map the codebase.
LACA maps the codebase, the task, and the agent's previous actions.
```

## v0.8.3 — Public Full Code Map

Added Python AST graph, query/path/explain, graph.html, incremental graph cache, optional Tree-sitter hooks, and compiler/syntax probes.

## v0.8.2 — Public Code Graph + Attention

Added code graph layer and transformer attention guide.

## v0.8.1 — Public BM25F + Cyrillic

Added BM25F-style field ranking and Unicode/Cyrillic tokenizer.

## v0.8 — Minimal User Manual

Added minimal user manual and simplified first-run/continue workflow.

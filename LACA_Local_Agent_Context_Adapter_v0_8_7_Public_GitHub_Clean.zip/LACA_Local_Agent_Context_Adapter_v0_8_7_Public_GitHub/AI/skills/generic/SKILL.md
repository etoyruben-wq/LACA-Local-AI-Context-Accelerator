---
name: laca-project-memory
summary: Use LACA project memory before editing a project that contains an AI folder.
---

# LACA Project Memory Skill

1. Read `AI/SKILL_PROTOCOL.md`.
2. Run `py AI\run.py continue`.
3. Read `AI_OUT/context_state.vmem`, `AI_OUT/action_points.tsv`, `AI_OUT/context_report.md`, and `AI_OUT/current_task.md`.
4. Check `AI_OUT/mistake_report.md`.
5. Make one focused change.
6. Create `RESULT.vmem` and run `py AI\run.py result`.

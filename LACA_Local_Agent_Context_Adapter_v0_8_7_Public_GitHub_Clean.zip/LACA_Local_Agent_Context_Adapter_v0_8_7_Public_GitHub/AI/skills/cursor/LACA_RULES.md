# LACA rules for Cursor-style agents

When the repository contains `AI/`, use LACA as the project memory layer:

1. Read `AI/SKILL_PROTOCOL.md`.
2. Run `py AI\run.py continue`.
3. Read `AI_OUT/context_state.vmem`, `AI_OUT/action_points.tsv`, `AI_OUT/current_task.md`, and `AI_OUT/attention_guide.md`.
4. Check `AI_OUT/mistake_report.md`.
5. Make one focused change.
6. Record `RESULT.vmem` and run `py AI\run.py result`.

# LACA instructions for Codex-style agents

If the repository contains an `AI` folder:

- Read `AI/SKILL_PROTOCOL.md` and the current task file.
- Run `py AI\run.py continue`.
- Use `AI_OUT/action_points.tsv` as the first file list.
- Use `AI_OUT/code_graph.json` and `AI_OUT/attention_guide.md` for routing.
- Check `AI_OUT/mistake_report.md` before repeating actions.
- Preserve the project's native architecture.
- At the end, write `RESULT.vmem` and run `py AI\run.py result`.

---
name: laca-antigravity-bootstrap
summary: Bootstrap Antigravity into LACA project memory and continue mode.
---

# LACA Antigravity Bootstrap

Use when the user says `LACA`, `continue`, `продовжити`, `start`, or when the project contains an `AI` folder.

1. Open `AI/SKILL_PROTOCOL.md`.
2. Run `py AI\run.py continue`.
3. Read `AI_OUT/context_state.vmem`, `AI_OUT/action_points.tsv`, and `AI_OUT/context_report.md`.
4. Check graph and mistake memory when relevant.
5. Make one focused change.
6. Create `RESULT.vmem` and run `py AI\run.py result`.

from __future__ import annotations

import argparse
import sys
from pathlib import Path
import hashlib
import json
import time

AI_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = AI_DIR.parent
LOCAL_SRC = AI_DIR / "src"
OUT_DIR_DEFAULT = PROJECT_ROOT / "AI_OUT"
STATE_DIR_DEFAULT = PROJECT_ROOT / "AI_STATE"

sys.path.insert(0, str(LOCAL_SRC))

from laca.cli import main as laca_main  # noqa: E402
from laca.code_graph import main as graph_main  # noqa: E402
from laca.agent_trace import record_agent_stamp, write_trace_reports, trace_summary_lines  # noqa: E402

DEFAULT_EXCLUDES = ",".join([
    ".git", ".hg", ".svn", ".idea", ".vscode",
    "node_modules", "bower_components", "dist", "build", "target", "out",
    ".venv", "venv", "env", "__pycache__", ".pytest_cache", ".mypy_cache",
    "AI", "AI_OUT", "AI_STATE", "laca_out",
])


TASK_FILE_CANDIDATES = [
    AI_DIR / "ТЗ_UA.md",
    AI_DIR / "TASK.md",
    AI_DIR / "TASK.txt",
]


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()


def read_task_document() -> dict:
    """Read the user task specification if present.

    The task/TZ file is intentionally simple: the user can open AI/ТЗ_UA.md and write
    what they are doing, what they want to get, and what the agent must focus on.
    Both first scan and continue always pull this file into the context.
    """
    for path in TASK_FILE_CANDIDATES:
        if path.exists():
            text = path.read_text(encoding="utf-8", errors="replace").strip()
            if text:
                return {
                    "path": str(path.relative_to(PROJECT_ROOT)).replace("\\", "/"),
                    "absolute_path": str(path),
                    "text": text,
                    "sha256": sha256_text(text),
                    "mtime": path.stat().st_mtime,
                }
    fallback = "Analyze this project and prepare the next exact development action."
    return {
        "path": "",
        "absolute_path": "",
        "text": fallback,
        "sha256": sha256_text(fallback),
        "mtime": time.time(),
    }


def summarize_task(text: str, max_chars: int = 420) -> str:
    lines = []
    boilerplate_markers = (
        "тз для ai", "task for ai", "цей файл", "this file", "агент має",
        "опиши", "напиши", "приклад", "example", "залиш", "заповнює",
        "що я зараз роблю", "що я хочу отримати", "на чому тримати",
        "що не можна", "важливі файли", "файли або папки", "критерій успіху",
        "що агент має", "what i am doing", "what i want", "what to focus",
        "what not to do", "important files", "success criteria", "final result",
    )
    for raw in text.splitlines():
        line = raw.strip().strip("#").strip()
        if not line or line.startswith("---") or line.startswith("```"):
            continue
        lower = line.lower()
        if any(marker in lower for marker in boilerplate_markers):
            continue
        if lower.startswith("-") and len(lower) < 4:
            continue
        lines.append(line)
        if len(" ".join(lines)) >= max_chars:
            break
    summary = " ".join(lines).strip()
    if not summary:
        summary = "analyze this project and prepare the next exact development action"
    return (summary[:max_chars] + "...") if len(summary) > max_chars else summary


def read_default_focus() -> str:
    task = read_task_document()
    if task["text"]:
        return summarize_task(task["text"], 900)
    return "analyze this project and prepare the next exact development action"


def write_task_state(out_dir: Path, state_dir: Path, mode: str) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    state_dir.mkdir(parents=True, exist_ok=True)
    task = read_task_document()
    previous_path = state_dir / "task_state.json"
    previous = {}
    if previous_path.exists():
        try:
            previous = json.loads(previous_path.read_text(encoding="utf-8"))
        except Exception:
            previous = {}
    changed = previous.get("sha256") != task["sha256"]
    record = {
        "version": "0.8.7",
        "mode": mode,
        "time": time.time(),
        "task_file": task["path"],
        "sha256": task["sha256"],
        "changed_since_last_run": changed,
        "summary": summarize_task(task["text"], 700),
    }
    previous_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    current_task = [
        "# Current Task / ТЗ",
        "",
        f"Task file: `{task['path'] or 'not found; fallback task used'}`",
        f"Task SHA256: `{task['sha256']}`",
        f"Changed since last run: `{changed}`",
        "",
        "## Summary",
        "",
        record["summary"],
        "",
        "## Full task text",
        "",
        task["text"],
        "",
    ]
    (out_dir / "current_task.md").write_text("\n".join(current_task), encoding="utf-8")
    return record


def inject_task_into_outputs(out_dir: Path, state_dir: Path, task_record: dict) -> None:
    """Make the pulled ТЗ visible to the agent in the compact output files."""
    context = out_dir / "context_state.vmem"
    task_line = (
        f"TASK|file={task_record.get('task_file') or 'none'}"
        f"|sha256={task_record.get('sha256')}"
        f"|changed={str(task_record.get('changed_since_last_run')).upper()}"
        f"|summary={str(task_record.get('summary','')).replace('|','/')}"
    )
    rule_line = "RULE|read_AI_OUT_current_task_md|task_spec_is_active_for_this_run"
    if context.exists():
        text = context.read_text(encoding="utf-8", errors="replace")
        if "TASK|file=" not in text:
            parts = text.splitlines()
            insert_at = 1 if parts else 0
            parts[insert_at:insert_at] = [task_line, rule_line]
            new_text = "\n".join(parts) + "\n"
            context.write_text(new_text, encoding="utf-8")
            (state_dir / "last_context_state.vmem").write_text(new_text, encoding="utf-8")
    report = out_dir / "context_report.md"
    if report.exists():
        text = report.read_text(encoding="utf-8", errors="replace")
        if "## Current task / ТЗ" not in text:
            block = (
                "\n## Current task / ТЗ\n\n"
                f"- Task file: `{task_record.get('task_file') or 'not found; fallback task used'}`\n"
                f"- Task changed since last run: **{task_record.get('changed_since_last_run')}**\n"
                f"- Task SHA256: `{task_record.get('sha256')}`\n\n"
                f"{task_record.get('summary','')}\n\n"
                "Agent must read `AI_OUT/current_task.md` together with `context_state.vmem` and `action_points.tsv`.\n"
            )
            report.write_text(text + block, encoding="utf-8")


def cmd_scan(args: argparse.Namespace) -> int:
    focus = args.focus or read_default_focus()
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    task_record = write_task_state(out_dir, state_dir, mode="scan")
    laca_args = [
        "scan",
        str(PROJECT_ROOT),
        "--focus", focus,
        "--project-name", args.project_name or PROJECT_ROOT.name,
        "--out", str(out_dir),
        "--state", str(state_dir),
        "--top-k", str(args.top_k),
        "--exclude-patterns", args.exclude_patterns or DEFAULT_EXCLUDES,
    ]
    if args.include_patterns:
        laca_args.extend(["--include-patterns", args.include_patterns])
    if args.progress:
        laca_args.append("--progress")
    rc = laca_main(laca_args)
    if rc == 0:
        inject_task_into_outputs(out_dir, state_dir, task_record)
        if not getattr(args, "no_graph", False):
            run_code_graph_layer(out_dir, state_dir, full=getattr(args, "graph_full", False), max_files=getattr(args, "graph_max_files", 500))
            inject_graph_into_outputs(out_dir)
        inject_trace_into_outputs(out_dir, state_dir)
        inject_skill_protocol_into_outputs(out_dir)
    return rc


def cmd_continue(args: argparse.Namespace) -> int:
    focus = args.focus or read_default_focus()
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    # If no persistent map exists yet, continue automatically falls back to a full scan.
    if not (state_dir / "project_map.json").exists():
        print("AI_STATE/project_map.json not found. Running first full scan instead.")
        return cmd_scan(args)
    task_record = write_task_state(out_dir, state_dir, mode="continue")
    laca_args = [
        "continue",
        str(PROJECT_ROOT),
        "--focus", focus,
        "--project-name", args.project_name or PROJECT_ROOT.name,
        "--out", str(out_dir),
        "--state", str(state_dir),
        "--top-k", str(args.top_k),
        "--exclude-patterns", args.exclude_patterns or DEFAULT_EXCLUDES,
    ]
    if args.include_patterns:
        laca_args.extend(["--include-patterns", args.include_patterns])
    if args.progress:
        laca_args.append("--progress")
    rc = laca_main(laca_args)
    if rc == 0:
        inject_task_into_outputs(out_dir, state_dir, task_record)
        if not getattr(args, "no_graph", False):
            run_code_graph_layer(out_dir, state_dir, full=getattr(args, "graph_full", False), max_files=getattr(args, "graph_max_files", 500))
            inject_graph_into_outputs(out_dir)
        inject_trace_into_outputs(out_dir, state_dir)
        inject_skill_protocol_into_outputs(out_dir)
    return rc


def cmd_result(args: argparse.Namespace) -> int:
    result_file = Path(args.result_file) if args.result_file else (PROJECT_ROOT / "RESULT.vmem")
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    if not result_file.exists():
        print(f"RESULT file not found: {result_file}", file=sys.stderr)
        return 2
    rc = laca_main(["result", str(result_file), "--out", str(out_dir), "--state", str(state_dir)])
    if rc == 0:
        stamp = record_agent_stamp(result_file, out_dir, state_dir, PROJECT_ROOT)
        inject_trace_into_outputs(out_dir, state_dir)
        inject_skill_protocol_into_outputs(out_dir)
        print(f"Recorded Agent Trace Stamp: {stamp.get('stamp_id')}")
    return rc



def run_code_graph_layer(out_dir: Path, state_dir: Path, *, full: bool = False, max_files: int = 500, query: str = "", path_from: str = "", path_to: str = "", compiler_probe: bool = False) -> int:
    """Build an optional code graph / attention guide.

    The graph layer is intentionally compact by default: it uses action_points.tsv
    as seed input so a large project does not dump thousands of files into the
    agent context. Use `AI/run.py graph --full` when a full code-map export is
    needed.
    """
    seed_file = out_dir / "action_points.tsv"
    args = [
        str(PROJECT_ROOT),
        "--out", str(out_dir),
        "--state", str(state_dir),
        "--seed-file", str(seed_file),
        "--max-files", str(max_files),
        "--exclude-patterns", DEFAULT_EXCLUDES,
    ]
    if full:
        args.append("--full")
    if query:
        args.extend(["--query", query])
    if path_from and path_to:
        args.extend(["--path-from", path_from, "--path-to", path_to])
    if compiler_probe:
        args.append("--compiler-probe")
    try:
        return graph_main(args)
    except Exception as exc:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "graph_error.txt").write_text(f"CODE_GRAPH_ERROR={exc}\n", encoding="utf-8")
        print(f"Code graph layer skipped: {exc}", file=sys.stderr)
        return 0


def inject_graph_into_outputs(out_dir: Path) -> None:
    context = out_dir / "context_state.vmem"
    attention = out_dir / "code_attention.vmem"
    if context.exists() and attention.exists():
        text = context.read_text(encoding="utf-8", errors="replace")
        if "GRAPH|version=" not in text:
            graph_lines = attention.read_text(encoding="utf-8", errors="replace").splitlines()[:28]
            new_text = text.rstrip() + "\n" + "\n".join(graph_lines) + "\n"
            context.write_text(new_text, encoding="utf-8")
    report = out_dir / "context_report.md"
    if report.exists() and (out_dir / "attention_guide.md").exists():
        text = report.read_text(encoding="utf-8", errors="replace")
        if "## Code graph / attention guide" not in text:
            block = """
## Code graph / attention guide

LACA generated an optional code graph layer for transformer-friendly routing:

- `AI_OUT/code_graph.json`
- `AI_OUT/code_symbols.tsv`
- `AI_OUT/import_edges.tsv`
- `AI_OUT/call_edges.tsv`
- `AI_OUT/attention_guide.md`
- `AI_OUT/graph.html`

Use this as an attention map. Do not paste the full graph into the prompt unless the user asks for it.
"""
            report.write_text(text.rstrip() + "\n" + block, encoding="utf-8")



def inject_trace_into_outputs(out_dir: Path, state_dir: Path) -> None:
    """Inject recent agent trace / mistake memory into compact context."""
    state_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_trace_reports(out_dir, state_dir)
    lines = trace_summary_lines(state_dir)
    context = out_dir / "context_state.vmem"
    if context.exists():
        text = context.read_text(encoding="utf-8", errors="replace")
        # remove old injected stamp block before writing a fresh one
        kept = [ln for ln in text.splitlines() if not (ln.startswith("STAMP|") or ln.startswith("STAMP_NEXT|") or ln.startswith("MISTAKE_MEMORY|") or ln.startswith("RULE|read_last_transformer_stamp_md"))]
        context.write_text("\n".join(kept + lines) + "\n", encoding="utf-8")
    report = out_dir / "context_report.md"
    if report.exists():
        text = report.read_text(encoding="utf-8", errors="replace")
        if "## Agent trace / mistake memory" not in text:
            block = """
## Agent trace / mistake memory

LACA generated an Agent Trace Stamp layer:

- `AI_OUT/last_transformer_stamp.md`
- `AI_OUT/agent_trace_report.md`
- `AI_OUT/mistake_report.md`
- `AI_STATE/agent_trace.jsonl`
- `AI_STATE/mistake_memory.jsonl`

Read it before repeating an action. If a previous action failed, do not repeat it unless the task conditions changed.
"""
            report.write_text(text.rstrip() + "\n" + block, encoding="utf-8")

def cmd_graph(args: argparse.Namespace) -> int:
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    rc = run_code_graph_layer(out_dir, state_dir, full=args.full, max_files=args.max_files, query=args.query or "", path_from=args.path_from or "", path_to=args.path_to or "", compiler_probe=args.compiler_probe)
    inject_graph_into_outputs(out_dir)
    inject_trace_into_outputs(out_dir, state_dir)
    inject_skill_protocol_into_outputs(out_dir)
    return rc


def cmd_trace(args: argparse.Namespace) -> int:
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    write_trace_reports(out_dir, state_dir)
    inject_trace_into_outputs(out_dir, state_dir)
    inject_skill_protocol_into_outputs(out_dir)
    print(f"Wrote {out_dir / 'last_transformer_stamp.md'}")
    print(f"Wrote {out_dir / 'agent_trace_report.md'}")
    print(f"Wrote {out_dir / 'mistake_report.md'}")
    return 0



def write_skill_protocol_reports(out_dir: Path) -> None:
    """Write a compact agent-readable skill protocol context."""
    out_dir.mkdir(parents=True, exist_ok=True)
    protocol_path = AI_DIR / "SKILL_PROTOCOL.md"
    protocol_ua_path = AI_DIR / "SKILL_PROTOCOL_UA.md"
    protocol_text = ""
    if protocol_path.exists():
        protocol_text = protocol_path.read_text(encoding="utf-8", errors="replace")
    elif protocol_ua_path.exists():
        protocol_text = protocol_ua_path.read_text(encoding="utf-8", errors="replace")

    compact = """# LACA Skill Protocol Context

Agent must use LACA as the project memory layer when the request is project-related.

## Required project workflow

1. Read `AI/TASK.md` or `AI/ТЗ_UA.md`.
2. Run `py AI\\run.py continue` unless the user explicitly asks for first scan.
3. Read `AI_OUT/context_state.vmem`, `AI_OUT/action_points.tsv`, `AI_OUT/context_report.md`, and `AI_OUT/current_task.md`.
4. Use `AI_OUT/code_graph.json` and `AI_OUT/attention_guide.md` when code structure matters.
5. Check `AI_OUT/mistake_report.md` before repeating previous actions.
6. Make one focused change.
7. Create `RESULT.vmem` and run `py AI\\run.py result`.

## Conflict rule

If the user request conflicts with the task file or LACA state, report `PROJECT_TASK_CONFLICT` and explain the conflict.

## Non-project rule

If the user request is not project-related, do not apply project restrictions.

## Architecture preservation rule

Preserve the project's native architecture. Do not rewrite the project into an unrelated template unless explicitly requested.
"""
    (out_dir / "skill_protocol_context.md").write_text(compact, encoding="utf-8")
    if protocol_text:
        (out_dir / "skill_protocol_full.md").write_text(protocol_text, encoding="utf-8")


def inject_skill_protocol_into_outputs(out_dir: Path) -> None:
    """Inject a short protocol pointer into compact context/report."""
    write_skill_protocol_reports(out_dir)
    context = out_dir / "context_state.vmem"
    skill_lines = [
        "SKILL|protocol=LACA_SKILL_PROTOCOL|version=0.8.7|file=AI/SKILL_PROTOCOL.md",
        "RULE|use_laca_project_memory_when_project_related|read_AI_OUT_skill_protocol_context_md",
        "RULE|task_priority|AI_TASK_or_TZ_has_priority_over_guessing",
        "RULE|result_writeback|required_RESULT_vmem_then_py_AI_run_py_result",
        "RULE|non_project_escape|do_not_apply_project_restrictions_to_non_project_questions",
    ]
    if context.exists():
        text = context.read_text(encoding="utf-8", errors="replace")
        kept = [ln for ln in text.splitlines() if not (ln.startswith("SKILL|protocol=") or ln.startswith("RULE|use_laca_project_memory") or ln.startswith("RULE|task_priority") or ln.startswith("RULE|result_writeback") or ln.startswith("RULE|non_project_escape"))]
        context.write_text("\n".join(kept + skill_lines) + "\n", encoding="utf-8")
    report = out_dir / "context_report.md"
    if report.exists():
        text = report.read_text(encoding="utf-8", errors="replace")
        if "## LACA Skill Protocol" not in text:
            block = """
## LACA Skill Protocol

LACA generated an agent-independent skill protocol context:

- `AI/SKILL_PROTOCOL.md`
- `AI/SKILL_PROTOCOL_UA.md`
- `AI_OUT/skill_protocol_context.md`
- `AI/skills/generic/SKILL.md`
- `AI/skills/codex/AGENT_INSTRUCTIONS.md`
- `AI/skills/antigravity/SKILL.md`
- `AI/skills/cursor/LACA_RULES.md`

Use this protocol when the request is project-related. If the request is not project-related, do not apply project restrictions.
"""
            report.write_text(text.rstrip() + "\n" + block, encoding="utf-8")


def cmd_skill(args: argparse.Namespace) -> int:
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    out_dir.mkdir(parents=True, exist_ok=True)
    state_dir.mkdir(parents=True, exist_ok=True)
    inject_skill_protocol_into_outputs(out_dir)
    print(f"Wrote {out_dir / 'skill_protocol_context.md'}")
    print(f"Protocol: {AI_DIR / 'SKILL_PROTOCOL.md'}")
    return 0

def cmd_status(args: argparse.Namespace) -> int:
    state_dir = Path(args.state) if args.state else STATE_DIR_DEFAULT
    out_dir = Path(args.out) if args.out else OUT_DIR_DEFAULT
    print(f"AI folder: {AI_DIR}")
    print(f"Project root: {PROJECT_ROOT}")
    print(f"Output folder: {out_dir}")
    print(f"Persistent state: {state_dir}")
    print(f"Map exists: {(state_dir / 'project_map.json').exists()}")
    print(f"Result history exists: {(state_dir / 'result_history.jsonl').exists()}")
    print(f"Change log exists: {(state_dir / 'change_log.jsonl').exists()}")
    print(f"Agent trace exists: {(state_dir / 'agent_trace.jsonl').exists()}")
    print(f"Mistake memory exists: {(state_dir / 'mistake_memory.jsonl').exists()}")
    print(f"Skill protocol exists: {(AI_DIR / 'SKILL_PROTOCOL.md').exists()}")
    return 0


def add_common_scan_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--focus", default="", help="Task focus. If omitted, AI/ТЗ_UA.md, AI/TASK.md, or AI/TASK.txt is used.")
    parser.add_argument("--top-k", type=int, default=25, help="Number of top files to export")
    parser.add_argument("--out", default="", help="Output folder. Default: ../AI_OUT")
    parser.add_argument("--state", default="", help="Persistent state folder. Default: ../AI_STATE")
    parser.add_argument("--project-name", default="", help="Human-readable project name")
    parser.add_argument("--include-patterns", default="", help="Comma-separated include patterns")
    parser.add_argument("--exclude-patterns", default="", help="Comma-separated exclude patterns")
    parser.add_argument("--progress", action="store_true", help="Print scan progress")
    parser.add_argument("--no-graph", action="store_true", help="Skip optional code graph / attention guide layer")
    parser.add_argument("--graph-full", action="store_true", help="Build full code graph up to --graph-max-files")
    parser.add_argument("--graph-max-files", type=int, default=500, help="Max files for graph layer")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="AI/run.py",
        description="Drop-in context scanner, code map, Agent Trace Stamp, and Skill Protocol for local AI coding agents.",
    )
    sub = parser.add_subparsers(dest="command")

    scan = sub.add_parser("scan", help="First/full scan of the parent project and write AI_OUT + AI_STATE")
    add_common_scan_args(scan)
    scan.set_defaults(func=cmd_scan)

    cont = sub.add_parser("continue", help="Continue from saved AI_STATE map; update changed files only")
    add_common_scan_args(cont)
    cont.set_defaults(func=cmd_continue)

    graph = sub.add_parser("graph", help="Build optional AST/code graph and transformer attention guide")
    graph.add_argument("--out", default="", help="Output folder. Default: ../AI_OUT")
    graph.add_argument("--state", default="", help="Persistent state folder. Default: ../AI_STATE")
    graph.add_argument("--full", action="store_true", help="Scan all supported code files up to --max-files")
    graph.add_argument("--max-files", type=int, default=500, help="Maximum code files to parse")
    graph.add_argument("--query", default="", help="Optional query to explain against code_graph.json")
    graph.add_argument("--path-from", default="", help="Find/explain graph path from this query")
    graph.add_argument("--path-to", default="", help="Find/explain graph path to this query")
    graph.add_argument("--compiler-probe", action="store_true", help="Run lightweight syntax/compile probes where available")
    graph.set_defaults(func=cmd_graph)


    trace = sub.add_parser("trace", help="Regenerate Agent Trace Stamp / mistake memory reports")
    trace.add_argument("--out", default="")
    trace.add_argument("--state", default="")
    trace.set_defaults(func=cmd_trace)

    result = sub.add_parser("result", help="Record RESULT.vmem into AI_STATE history and change log")
    result.add_argument("result_file", nargs="?", default="", help="RESULT.vmem path. Default: ../RESULT.vmem")
    result.add_argument("--out", default="", help="Output folder. Default: ../AI_OUT")
    result.add_argument("--state", default="", help="Persistent state folder. Default: ../AI_STATE")
    result.set_defaults(func=cmd_result)

    skill = sub.add_parser("skill", help="Write compact LACA Skill Protocol context for agents")
    skill.add_argument("--out", default="")
    skill.add_argument("--state", default="")
    skill.set_defaults(func=cmd_skill)

    status = sub.add_parser("status", help="Show current AI_OUT/AI_STATE status")
    status.add_argument("--out", default="")
    status.add_argument("--state", default="")
    status.set_defaults(func=cmd_status)
    return parser


def main(argv=None) -> int:
    parser = build_parser()
    if argv is None and len(sys.argv) == 1:
        # Default behavior for agents: continue if possible, otherwise first scan.
        return cmd_continue(argparse.Namespace(
            focus="", top_k=25, out="", state="", project_name="", include_patterns="",
            exclude_patterns="", progress=False, no_graph=False, graph_full=False, graph_max_files=500,
        ))
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

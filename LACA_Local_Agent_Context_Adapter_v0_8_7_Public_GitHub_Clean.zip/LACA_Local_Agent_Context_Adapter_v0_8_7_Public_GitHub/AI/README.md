# LACA Local Agent Context Adapter v0.8.7 Public — GitHub Clean

LACA is a local-first, agent-independent project memory harness for AI coding agents. Copy the `AI` folder into a project root and let the agent read it before working.

v0.8.7 includes:

- BM25F-style field ranking;
- Unicode/Cyrillic tokenization;
- persistent project map and continue mode;
- task files: `AI/ТЗ_UA.md` and `AI/TASK.md`;
- Python AST code graph;
- functions/classes/methods;
- imports/calls/inheritance edges;
- `code_graph.json`, TSV edges, and `graph.html`;
- query/path/explain layer;
- transformer attention guide;
- Agent Trace Stamp / mistake memory;
- public LACA Skill Protocol for Codex, Antigravity, Cursor, and generic agents.

## First run

Tell the agent:

```text
There is an AI folder in the project root. Open it and follow the instruction inside.
```

Or Ukrainian:

```text
У папці проєкту є папка AI. В папці є інструкція. Виконай інструкцію.
```

Manual command:

```bat
py AI\run.py scan
```

## Continue

Tell the agent:

```text
There is an AI folder in the project root. There is a CONTINUE instruction. Execute it.
```

Or Ukrainian:

```text
У папці проєкту є папка AI. Там є інструкція ПРОДОВЖИТИ. Виконай.
```

Manual command:

```bat
py AI\run.py continue
```

## Code graph

```bat
py AI\run.py graph
py AI\run.py graph --query "SomeClass"
py AI\run.py graph --path-from "entry" --path-to "target"
```

## Agent Trace Stamp

After an agent action, create `RESULT.vmem`, then run:

```bat
py AI\run.py result
```

LACA records the action in:

```text
AI_STATE/agent_trace.jsonl
AI_STATE/transformer_stamp.jsonl
AI_STATE/mistake_memory.jsonl
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
```

This helps the next agent run avoid repeated failed actions.

## Core idea

Graph tools map the codebase. LACA maps the codebase, the task, and the agent's previous actions.


## LACA Skill Protocol

v0.8.7 adds an agent-independent skill protocol. It tells any AI coding agent how to use the local LACA project memory before editing files.

Main files:

```text
AI/SKILL_PROTOCOL.md
AI/SKILL_PROTOCOL_UA.md
AI/AGENT_BOOTSTRAP.md
AI/AGENT_BOOTSTRAP_UA.md
AI/skills/generic/SKILL.md
AI/skills/codex/AGENT_INSTRUCTIONS.md
AI/skills/antigravity/SKILL.md
AI/skills/cursor/LACA_RULES.md
```

Manual command:

```bat
py AI
un.py skill
```

Generated output:

```text
AI_OUT/skill_protocol_context.md
AI_OUT/skill_protocol_full.md
```

The protocol keeps the public version neutral: it asks the agent to preserve the project’s native architecture, read the task file, use the project map, check mistake memory, make one focused change, and write back `RESULT.vmem`.


## Public GitHub clean scope

This package intentionally excludes multi-agent parallel coordination, private vector architecture guards, private accelerators, Android companion logic, and private project-specific rules. Those belong in separate private or future releases.

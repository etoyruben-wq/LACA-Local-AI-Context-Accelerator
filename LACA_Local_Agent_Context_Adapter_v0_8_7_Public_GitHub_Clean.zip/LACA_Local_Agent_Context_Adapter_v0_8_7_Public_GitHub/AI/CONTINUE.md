# Continue instruction for AI agent

1. Read `AI/TASK.md` or `AI/ТЗ_UA.md`.
2. Run:

```bat
py AI\run.py continue
```

If `py` is not available, run:

```bat
python AI\run.py continue
```

3. Read:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
```

4. Continue from the saved project map. Do not start from zero.
5. If `mistake_report.md` contains a failed action, do not repeat it unless the user explicitly asks or the conditions changed.
6. Do one focused action.
7. Create `RESULT.vmem`.
8. Run:

```bat
py AI\run.py result
```

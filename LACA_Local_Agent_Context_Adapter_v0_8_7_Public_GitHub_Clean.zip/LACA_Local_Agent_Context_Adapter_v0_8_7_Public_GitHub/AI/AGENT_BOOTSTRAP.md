# LACA Agent Bootstrap

For an AI coding agent entering a project with an `AI` folder.

Run:

```bat
py AI\run.py continue
```

Then read:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/mistake_report.md
```

After the action, create `RESULT.vmem` and run:

```bat
py AI\run.py result
```

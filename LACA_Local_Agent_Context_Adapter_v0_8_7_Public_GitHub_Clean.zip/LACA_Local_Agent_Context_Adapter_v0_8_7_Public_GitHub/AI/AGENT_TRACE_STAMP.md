# Agent Trace Stamp / Печатка трансформатора

LACA v0.8.4 adds an Agent Trace Stamp layer.

The code graph shows what exists in the project. The Agent Trace Stamp shows what the AI agent already did.

This prevents the agent from wasting time on repeated discovery and from repeating failed actions.

## What is recorded

After every completed agent action, the agent should create `RESULT.vmem` and run:

```bat
py AI\run.py result
```

LACA then records:

- the result status: PASS / FAIL / BLOCKED;
- the task name;
- changed files;
- evidence;
- next step;
- files read or changed, if the agent reports them;
- mistakes, wrong actions, errors, and blockers;
- hashes of the context, task state, graph, project map, and RESULT file.

## Output files

```text
AI_STATE/agent_trace.jsonl
AI_STATE/transformer_stamp.jsonl
AI_STATE/mistake_memory.jsonl

AI_OUT/last_transformer_stamp.md
AI_OUT/agent_trace_report.md
AI_OUT/mistake_report.md
```

## RESULT.vmem format

Minimal successful result:

```text
RESULT|status=PASS|task=short_task_name
CHANGED|src/example.py
EVIDENCE|tests passed
NEXT|continue with the next focused action
```

With explicit mistake memory:

```text
RESULT|status=FAIL|task=fix_runner
MISTAKE|opened deprecated archive runner
WRONG_ACTION|used archive/old_runner.bat instead of current runner
LESSON|do not use archive/ unless the user explicitly asks for historical files
EVIDENCE|command failed with stale path
NEXT|use the current runner from action_points.tsv
```

## Rule for agents

Before repeating a failed action, read:

```text
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
AI_STATE/mistake_memory.jsonl
```

Do not repeat a recorded failed action unless the task conditions changed or the user explicitly asks to retry.

## Positioning

Graphify-style tools primarily map code structure.

LACA maps:

1. project files;
2. task specification;
3. code graph;
4. attention guide;
5. previous agent actions;
6. previous mistakes.

Public phrase:

```text
LACA maps the codebase, the task, and the agent's previous actions.
```

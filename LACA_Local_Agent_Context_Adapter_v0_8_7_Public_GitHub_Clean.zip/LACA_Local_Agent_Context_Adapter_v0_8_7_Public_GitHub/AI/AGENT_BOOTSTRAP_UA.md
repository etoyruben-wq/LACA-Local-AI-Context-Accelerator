# LACA Agent Bootstrap / Швидкий старт агента

Для AI-агента, який заходить у проєкт з папкою `AI`.

Виконати:

```bat
py AI\run.py continue
```

Потім прочитати:

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/attention_guide.md
AI_OUT/mistake_report.md
```

Після дії створити `RESULT.vmem` і виконати:

```bat
py AI\run.py result
```

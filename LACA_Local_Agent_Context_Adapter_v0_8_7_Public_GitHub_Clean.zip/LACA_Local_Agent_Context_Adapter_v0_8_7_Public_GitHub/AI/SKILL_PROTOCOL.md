# LACA Skill Protocol

Version: 0.8.7 public

LACA Skill Protocol is an agent-independent protocol for using a project-local `AI` folder. It tells any AI coding agent how to use LACA project memory before editing files.

## Core rule

If a project contains an `AI` folder and the request is project-related, do not start from zero. Use LACA first.

## Agent workflow

1. Read the task file: `AI/TASK.md`, `AI/TASK.txt`, or `AI/ТЗ_UA.md`.
2. Run `py AI\run.py continue`. If no saved map exists, it falls back to the first scan.
3. Read `AI_OUT/context_state.vmem`, `AI_OUT/action_points.tsv`, `AI_OUT/context_report.md`, and `AI_OUT/current_task.md`.
4. Use `AI_OUT/code_graph.json`, `AI_OUT/graph_report.md`, and `AI_OUT/attention_guide.md` when code structure matters.
5. Read `AI_OUT/last_transformer_stamp.md` and `AI_OUT/mistake_report.md` before repeating an action.
6. Make one focused change.
7. Create `RESULT.vmem` and run `py AI\run.py result`.

## Conflict rule

If the new request conflicts with the task file or the saved LACA state, report `PROJECT_TASK_CONFLICT` and explain the conflict.

## Non-project rule

If the request is not related to the current project, do not apply project restrictions.

## Architecture preservation rule

Preserve the project's native architecture. Do not rewrite the project into an unrelated standard template unless explicitly requested.

## RESULT.vmem format

```text
RESULT|status=PASS/BLOCKED/FAIL|task=short_task_name
CHANGED|path/to/file
EVIDENCE|what proves the result
MISTAKE|optional mistake or none
NEXT|next recommended step
```

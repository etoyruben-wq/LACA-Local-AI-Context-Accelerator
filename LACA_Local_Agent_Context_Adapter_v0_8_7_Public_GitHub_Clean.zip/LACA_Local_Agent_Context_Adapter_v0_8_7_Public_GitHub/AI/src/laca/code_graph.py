from __future__ import annotations

import argparse
import ast
import fnmatch
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence, Any

VERSION = "0.8.7"

DEFAULT_EXCLUDE_DIRS = {
    ".git", ".hg", ".svn", ".idea", ".vscode", "node_modules", "bower_components",
    "dist", "build", "target", "out", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".venv", "venv", "env", "AI", "AI_OUT", "AI_STATE", "coverage",
}

CODE_EXTENSIONS = {
    ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx",
    ".c", ".h", ".cpp", ".hpp", ".cc", ".hh",
    ".rs", ".go", ".java", ".cs", ".php", ".rb",
}

JS_IMPORT_RE = re.compile(r"(?:import\s+(?:[^'\"]+\s+from\s+)?|require\s*\()\s*['\"]([^'\"]+)['\"]")
JS_FUNC_RE = re.compile(r"(?:function\s+([\w$\u0080-\uffff]+)|(?:const|let|var)\s+([\w$\u0080-\uffff]+)\s*=\s*(?:async\s*)?\(?[^=]*?\)?\s*=>|class\s+([\w$\u0080-\uffff]+)(?:\s+extends\s+([\w$.\u0080-\uffff]+))?)")
JS_CALL_RE = re.compile(r"(?<!function\s)(?<!class\s)([\w$\u0080-\uffff][\w$.\u0080-\uffff]*)\s*\(")
CPP_INCLUDE_RE = re.compile(r"#\s*include\s*[<\"]([^>\"]+)[>\"]")
CPP_SYMBOL_RE = re.compile(r"(?:class|struct)\s+([A-Za-z_\u0080-\uffff]\w*)|(?:[A-Za-z_~][\w:<>,~*&\s]+)\s+([A-Za-z_\u0080-\uffff]\w*)\s*\([^;{}]*\)\s*(?:\{|;)")
CPP_CALL_RE = re.compile(r"([A-Za-z_\u0080-\uffff]\w*(?:::\w+)*)\s*\(")
GO_SYMBOL_RE = re.compile(r"func\s+(?:\([^)]*\)\s*)?([A-Za-z_\u0080-\uffff]\w*)\s*\(")
RUST_SYMBOL_RE = re.compile(r"(?:fn|struct|enum|trait|impl)\s+([A-Za-z_\u0080-\uffff]\w*)")
JAVA_SYMBOL_RE = re.compile(r"(?:class|interface|enum)\s+([A-Za-z_\u0080-\uffff]\w*)|(?:public|private|protected|static|final|synchronized|native|abstract|\s)+[\w<>\[\]]+\s+([A-Za-z_\u0080-\uffff]\w*)\s*\(")
CS_SYMBOL_RE = re.compile(r"(?:class|interface|struct|enum)\s+([A-Za-z_\u0080-\uffff]\w*)|(?:public|private|protected|internal|static|async|virtual|override|sealed|\s)+[\w<>\[\]]+\s+([A-Za-z_\u0080-\uffff]\w*)\s*\(")

@dataclass
class GraphNode:
    id: str
    type: str
    path: str = ""
    name: str = ""
    line: int = 0
    language: str = ""

@dataclass
class GraphEdge:
    source: str
    target: str
    type: str
    path: str = ""
    line: int = 0
    detail: str = ""


def now() -> float:
    return time.time()


def normalize_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def sha256_file(path: Path, limit: int | None = None) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        if limit is None:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        else:
            h.update(f.read(limit))
    return h.hexdigest()


def safe_read_text(path: Path, max_bytes: int = 1024 * 1024) -> str:
    with path.open("rb") as f:
        data = f.read(max_bytes)
    return data.decode("utf-8", errors="replace")


def should_skip(path: Path, root: Path, exclude_patterns: list[str]) -> bool:
    try:
        rel_parts = path.relative_to(root).parts
        rel = str(path.relative_to(root)).replace("\\", "/")
    except Exception:
        rel_parts = path.parts
        rel = str(path).replace("\\", "/")
    for part in rel_parts:
        if part in DEFAULT_EXCLUDE_DIRS:
            return True
    return any(fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(path.name, pat) for pat in exclude_patterns)


def iter_code_files(root: Path, exclude_patterns: list[str]) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if should_skip(path, root, exclude_patterns):
            continue
        if path.suffix.lower() in CODE_EXTENSIONS:
            yield path


def read_seed_paths(seed_file: Path | None, root: Path) -> set[str]:
    result: set[str] = set()
    if not seed_file or not seed_file.exists():
        return result
    try:
        lines = seed_file.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return result
    for line in lines:
        if not line.strip() or line.lower().startswith("rank"):
            continue
        parts = line.split("\t")
        for part in parts:
            p = part.strip().strip("`")
            if not p or ("/" not in p and "\\" not in p and "." not in p):
                continue
            candidate = (root / p).resolve()
            if candidate.exists() and candidate.is_file():
                try:
                    result.add(normalize_rel(candidate, root))
                except Exception:
                    pass
                break
    return result


def dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = dotted_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    if isinstance(node, ast.Call):
        return dotted_name(node.func)
    if isinstance(node, ast.Subscript):
        return dotted_name(node.value)
    try:
        return ast.unparse(node)
    except Exception:
        return ""


def lang_for(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in {".py", ".pyi"}: return "python"
    if ext in {".js", ".jsx", ".ts", ".tsx"}: return "javascript/typescript"
    if ext in {".c", ".h", ".cpp", ".hpp", ".cc", ".hh"}: return "c/cpp"
    if ext == ".rs": return "rust"
    if ext == ".go": return "go"
    if ext == ".java": return "java"
    if ext == ".cs": return "csharp"
    if ext == ".php": return "php"
    if ext == ".rb": return "ruby"
    return ext.lstrip(".")


def file_id(rel: str) -> str:
    return f"file:{rel}"


def symbol_id(rel: str, name: str, line: int) -> str:
    safe = name.replace(" ", "_").replace("|", "_")
    return f"symbol:{rel}:{safe}:{line}"


def parse_python(path: Path, rel: str, text: str) -> tuple[list[GraphNode], list[GraphEdge], list[str]]:
    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []
    errors: list[str] = []
    fid = file_id(rel)
    try:
        tree = ast.parse(text, filename=rel)
    except SyntaxError as e:
        errors.append(f"{rel}:{e.lineno}: syntax error: {e.msg}")
        return nodes, edges, errors
    except Exception as e:
        errors.append(f"{rel}: parse error: {e}")
        return nodes, edges, errors

    class_stack: list[str] = []
    current_symbol: list[str] = []

    class Visitor(ast.NodeVisitor):
        def visit_Import(self, node: ast.Import) -> None:
            for alias in node.names:
                edges.append(GraphEdge(fid, f"module:{alias.name}", "imports", rel, getattr(node, "lineno", 0), alias.asname or ""))
            self.generic_visit(node)

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            module = node.module or ""
            for alias in node.names:
                target = f"module:{module}.{alias.name}" if module else f"module:{alias.name}"
                edges.append(GraphEdge(fid, target, "imports", rel, getattr(node, "lineno", 0), alias.asname or ""))
            self.generic_visit(node)

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            sid = symbol_id(rel, node.name, node.lineno)
            nodes.append(GraphNode(sid, "class", rel, node.name, node.lineno, "python"))
            edges.append(GraphEdge(fid, sid, "contains", rel, node.lineno, "class"))
            for base in node.bases:
                base_name = dotted_name(base)
                if base_name:
                    edges.append(GraphEdge(sid, f"symbol-ref:{base_name}", "inherits", rel, node.lineno, base_name))
            class_stack.append(node.name)
            current_symbol.append(sid)
            self.generic_visit(node)
            current_symbol.pop()
            class_stack.pop()

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self._visit_func(node)

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self._visit_func(node)

        def _visit_func(self, node: ast.AST) -> None:
            name = getattr(node, "name", "")
            display = f"{class_stack[-1]}.{name}" if class_stack else name
            sid = symbol_id(rel, display, getattr(node, "lineno", 0))
            ntype = "method" if class_stack else "function"
            nodes.append(GraphNode(sid, ntype, rel, display, getattr(node, "lineno", 0), "python"))
            parent = current_symbol[-1] if current_symbol else fid
            edges.append(GraphEdge(parent, sid, "contains", rel, getattr(node, "lineno", 0), ntype))
            current_symbol.append(sid)
            self.generic_visit(node)
            current_symbol.pop()

        def visit_Call(self, node: ast.Call) -> None:
            name = dotted_name(node.func)
            if name:
                src = current_symbol[-1] if current_symbol else fid
                edges.append(GraphEdge(src, f"call:{name}", "calls", rel, getattr(node, "lineno", 0), name))
            self.generic_visit(node)

    Visitor().visit(tree)
    return nodes, edges, errors


def add_regex_calls(text: str, rel: str, fid: str, regex: re.Pattern, edges: list[GraphEdge], skip: set[str] | None = None) -> None:
    skip = skip or set()
    for m in regex.finditer(text):
        name = m.group(1)
        if not name or name in skip:
            continue
        line = text.count("\n", 0, m.start()) + 1
        edges.append(GraphEdge(fid, f"call:{name}", "calls", rel, line, name))


def parse_regex_code(path: Path, rel: str, text: str) -> tuple[list[GraphNode], list[GraphEdge], list[str]]:
    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []
    errors: list[str] = []
    fid = file_id(rel)
    ext = path.suffix.lower()
    language = lang_for(path)
    if ext in {".js", ".jsx", ".ts", ".tsx"}:
        for m in JS_IMPORT_RE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            edges.append(GraphEdge(fid, f"module:{m.group(1)}", "imports", rel, line, "regex"))
        for m in JS_FUNC_RE.finditer(text):
            name = next((g for g in m.groups()[:3] if g), "")
            base = m.group(4) if len(m.groups()) > 3 else ""
            line = text.count("\n", 0, m.start()) + 1
            if name:
                typ = "class" if m.group(3) else "function"
                sid = symbol_id(rel, name, line)
                nodes.append(GraphNode(sid, typ, rel, name, line, language))
                edges.append(GraphEdge(fid, sid, "contains", rel, line, "regex"))
                if base:
                    edges.append(GraphEdge(sid, f"symbol-ref:{base}", "inherits", rel, line, base))
        add_regex_calls(text, rel, fid, JS_CALL_RE, edges, {"if", "for", "while", "switch", "catch", "function"})
    elif ext in {".c", ".h", ".cpp", ".hpp", ".cc", ".hh"}:
        for m in CPP_INCLUDE_RE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            edges.append(GraphEdge(fid, f"include:{m.group(1)}", "imports", rel, line, "include"))
        for m in CPP_SYMBOL_RE.finditer(text):
            name = m.group(1) or m.group(2)
            line = text.count("\n", 0, m.start()) + 1
            if name:
                typ = "class" if m.group(1) else "function"
                sid = symbol_id(rel, name, line)
                nodes.append(GraphNode(sid, typ, rel, name, line, language))
                edges.append(GraphEdge(fid, sid, "contains", rel, line, "regex"))
        add_regex_calls(text, rel, fid, CPP_CALL_RE, edges, {"if", "for", "while", "switch", "return", "sizeof"})
    elif ext == ".go":
        for m in GO_SYMBOL_RE.finditer(text):
            name = m.group(1)
            line = text.count("\n", 0, m.start()) + 1
            sid = symbol_id(rel, name, line)
            nodes.append(GraphNode(sid, "function", rel, name, line, language))
            edges.append(GraphEdge(fid, sid, "contains", rel, line, "regex"))
        add_regex_calls(text, rel, fid, re.compile(r"([A-Za-z_\u0080-\uffff]\w*)\s*\("), edges, {"if", "for", "switch", "return", "func"})
    elif ext == ".rs":
        for m in RUST_SYMBOL_RE.finditer(text):
            name = m.group(1)
            line = text.count("\n", 0, m.start()) + 1
            typ = "function" if text[m.start():m.start()+3] == "fn " else "class"
            sid = symbol_id(rel, name, line)
            nodes.append(GraphNode(sid, typ, rel, name, line, language))
            edges.append(GraphEdge(fid, sid, "contains", rel, line, "regex"))
        add_regex_calls(text, rel, fid, re.compile(r"([A-Za-z_\u0080-\uffff]\w*)!?:?\s*\("), edges, {"if", "for", "while", "match", "fn"})
    elif ext in {".java", ".cs"}:
        rx = JAVA_SYMBOL_RE if ext == ".java" else CS_SYMBOL_RE
        for m in rx.finditer(text):
            name = m.group(1) or m.group(2)
            line = text.count("\n", 0, m.start()) + 1
            typ = "class" if m.group(1) else "function"
            sid = symbol_id(rel, name, line)
            nodes.append(GraphNode(sid, typ, rel, name, line, language))
            edges.append(GraphEdge(fid, sid, "contains", rel, line, "regex"))
        add_regex_calls(text, rel, fid, re.compile(r"([A-Za-z_\u0080-\uffff]\w*)\s*\("), edges, {"if", "for", "while", "switch", "catch", "return"})
    return nodes, edges, errors


def detect_tree_sitter() -> dict[str, Any]:
    info = {"available": False, "package": "", "languages": [], "note": "not installed; regex/AST fallback active"}
    try:
        import tree_sitter  # type: ignore # noqa
        info["available"] = True
        info["package"] = "tree_sitter"
        info["note"] = "tree_sitter core detected; language bindings may still be required"
    except Exception:
        return info
    try:
        import tree_sitter_languages  # type: ignore # noqa
        info["package"] = "tree_sitter + tree_sitter_languages"
        info["languages"] = ["python", "javascript", "typescript", "c", "cpp", "go", "rust", "java"]
        info["note"] = "optional language package detected; future/parser-specific use enabled by environment"
    except Exception:
        pass
    return info


def parser_mode_for(path: Path, tree_info: dict[str, Any]) -> str:
    # Public v0.8.3 keeps stdlib AST for Python and regex fallback for other languages.
    # Tree-sitter is detected and reported, but never required; this keeps the drop-in package dependency-free.
    if path.suffix.lower() in {".py", ".pyi"}:
        return "python_ast"
    return "regex_fallback" if not tree_info.get("available") else "regex_fallback_with_tree_sitter_available"


def load_cache(state_dir: Path) -> dict[str, Any]:
    path = state_dir / "code_graph_cache.json"
    if not path.exists():
        return {"version": VERSION, "files": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        if isinstance(data, dict) and isinstance(data.get("files"), dict):
            return data
    except Exception:
        pass
    return {"version": VERSION, "files": {}}


def save_cache(state_dir: Path, cache: dict[str, Any]) -> None:
    cache["version"] = VERSION
    cache["generated_at"] = now()
    (state_dir / "code_graph_cache.json").write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def compiler_probe(path: Path, rel: str, language: str) -> dict[str, Any] | None:
    ext = path.suffix.lower()
    if ext in {".py", ".pyi"}:
        cmd = [sys.executable, "-m", "py_compile", str(path)]
    elif ext in {".c"} and shutil.which("gcc"):
        cmd = ["gcc", "-fsyntax-only", str(path)]
    elif ext in {".cpp", ".hpp", ".cc", ".hh", ".h"} and shutil.which("g++"):
        cmd = ["g++", "-fsyntax-only", str(path)]
    else:
        return {"path": rel, "language": language, "status": "SKIPPED", "reason": "no compiler/probe available", "cmd": ""}
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        return {
            "path": rel,
            "language": language,
            "status": "PASS" if proc.returncode == 0 else "FAIL",
            "returncode": proc.returncode,
            "cmd": " ".join(cmd),
            "stdout": (proc.stdout or "")[-4000:],
            "stderr": (proc.stderr or "")[-4000:],
        }
    except Exception as exc:
        return {"path": rel, "language": language, "status": "BLOCKED", "reason": str(exc), "cmd": " ".join(cmd)}


def parse_one_file(path: Path, root: Path, tree_info: dict[str, Any], compiler_probe_enabled: bool) -> dict[str, Any]:
    rel = normalize_rel(path, root)
    language = lang_for(path)
    fid = file_id(rel)
    digest = sha256_file(path, limit=512 * 1024)
    nodes = [asdict(GraphNode(fid, "file", rel, path.name, 0, language))]
    edges: list[dict[str, Any]] = []
    errors: list[str] = []
    try:
        raw = safe_read_text(path)
    except Exception as e:
        errors.append(f"{rel}: read error: {e}")
        raw = ""
    if raw:
        if path.suffix.lower() in {".py", ".pyi"}:
            ns, es, er = parse_python(path, rel, raw)
        else:
            ns, es, er = parse_regex_code(path, rel, raw)
        nodes.extend(asdict(n) for n in ns)
        edges.extend(asdict(e) for e in es)
        errors.extend(er)
    probe = compiler_probe(path, rel, language) if compiler_probe_enabled else None
    return {
        "path": rel,
        "language": language,
        "sha256_head": digest,
        "parser_mode": parser_mode_for(path, tree_info),
        "nodes": nodes,
        "edges": edges,
        "errors": errors,
        "compiler_probe": probe,
        "file_record": {"path": rel, "language": language, "sha256_head": digest, "symbols": max(0, len(nodes) - 1), "edges": len(edges), "parser_mode": parser_mode_for(path, tree_info)},
    }


def build_graph(root: Path, out_dir: Path, state_dir: Path, *, seed_file: Path | None = None, full: bool = False, max_files: int = 500, exclude_patterns: list[str] | None = None, query: str = "", path_from: str = "", path_to: str = "", compiler_probe_enabled: bool = False) -> dict:
    root = root.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    state_dir.mkdir(parents=True, exist_ok=True)
    exclude_patterns = exclude_patterns or []
    tree_info = detect_tree_sitter()
    seed_paths = read_seed_paths(seed_file, root)
    all_code_files = list(iter_code_files(root, exclude_patterns))
    selected: list[Path] = []
    if full:
        selected = all_code_files[:max_files] if max_files > 0 else all_code_files
    else:
        if seed_paths:
            for p in all_code_files:
                rel = normalize_rel(p, root)
                if rel in seed_paths:
                    selected.append(p)
        if len(selected) < min(25, max_files):
            for p in all_code_files:
                if p not in selected:
                    selected.append(p)
                if len(selected) >= max_files:
                    break
        selected = selected[:max_files]

    cache = load_cache(state_dir)
    cache_files = cache.setdefault("files", {})
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    errors: list[str] = []
    file_records: list[dict] = []
    language_counts: Counter[str] = Counter()
    parser_counts: Counter[str] = Counter()
    compiler_results: list[dict[str, Any]] = []
    reused = 0
    changed = 0

    for path in selected:
        rel = normalize_rel(path, root)
        language = lang_for(path)
        language_counts[language] += 1
        try:
            digest = sha256_file(path, limit=512 * 1024)
        except Exception:
            digest = ""
        cached = cache_files.get(rel)
        if cached and cached.get("sha256_head") == digest and cached.get("version") == VERSION and not compiler_probe_enabled:
            parsed = cached["parsed"]
            reused += 1
        else:
            parsed = parse_one_file(path, root, tree_info, compiler_probe_enabled)
            cache_files[rel] = {"version": VERSION, "sha256_head": parsed["sha256_head"], "mtime": path.stat().st_mtime, "parsed": parsed}
            changed += 1
        nodes.extend(parsed.get("nodes", []))
        edges.extend(parsed.get("edges", []))
        errors.extend(parsed.get("errors", []))
        file_records.append(parsed.get("file_record", {"path": rel, "language": language, "sha256_head": digest}))
        parser_counts[parsed.get("parser_mode", "unknown")] += 1
        if parsed.get("compiler_probe"):
            compiler_results.append(parsed["compiler_probe"])

    # remove stale cache entries for files no longer present in selected/all_code_files root
    current_rels = {normalize_rel(p, root) for p in all_code_files}
    for rel in list(cache_files.keys()):
        if rel not in current_rels:
            cache_files.pop(rel, None)
    save_cache(state_dir, cache)

    graph = {
        "version": VERSION,
        "generated_at": now(),
        "root": str(root),
        "mode": "full" if full else "seeded",
        "scanned_code_files": len(selected),
        "available_code_files": len(all_code_files),
        "max_files": max_files,
        "seed_file": str(seed_file) if seed_file else "",
        "languages": dict(language_counts),
        "parser_modes": dict(parser_counts),
        "tree_sitter": tree_info,
        "cache": {"reused": reused, "parsed_or_changed": changed, "entries": len(cache_files)},
        "compiler_probe_enabled": compiler_probe_enabled,
        "compiler_results": compiler_results,
        "nodes": nodes,
        "edges": edges,
        "errors": errors[:500],
        "files": file_records,
    }
    write_graph_outputs(graph, out_dir, state_dir)
    if query:
        explain_query(query, out_dir)
    if path_from and path_to:
        explain_path(path_from, path_to, out_dir)
    return graph


def write_tsv(path: Path, rows: list[list[Any]]) -> None:
    path.write_text("\n".join("\t".join(str(c).replace("\t", " ").replace("\n", " ") for c in row) for row in rows) + "\n", encoding="utf-8")


def build_indexes(graph: dict) -> dict[str, Any]:
    nodes_by_id = {n["id"]: n for n in graph.get("nodes", [])}
    label_by_id = {}
    for n in graph.get("nodes", []):
        label_by_id[n["id"]] = n.get("name") or n.get("path") or n["id"]
    adjacency: dict[str, list[dict[str, Any]]] = defaultdict(list)
    reverse: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for e in graph.get("edges", []):
        adjacency[e["source"]].append(e)
        reverse[e["target"]].append(e)
    return {"nodes_by_id": nodes_by_id, "labels": label_by_id, "adjacency": adjacency, "reverse": reverse}


def write_graph_outputs(graph: dict, out_dir: Path, state_dir: Path) -> None:
    (out_dir / "code_graph.json").write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")
    (state_dir / "code_graph.json").write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")

    symbol_rows = [["type", "name", "path", "line", "language", "id"]]
    for n in graph["nodes"]:
        if n["type"] in {"class", "function", "method"}:
            symbol_rows.append([n["type"], n["name"], n["path"], n["line"], n["language"], n["id"]])
    write_tsv(out_dir / "code_symbols.tsv", symbol_rows)

    import_rows = [["source", "target", "path", "line", "detail"]]
    call_rows = [["source", "target", "path", "line", "detail"]]
    inherits_rows = [["source", "target", "path", "line", "detail"]]
    edge_rows = [["type", "source", "target", "path", "line", "detail"]]
    for e in graph["edges"]:
        row = [e["source"], e["target"], e["path"], e["line"], e["detail"]]
        edge_rows.append([e["type"], *row])
        if e["type"] == "imports": import_rows.append(row)
        elif e["type"] == "calls": call_rows.append(row)
        elif e["type"] == "inherits": inherits_rows.append(row)
    write_tsv(out_dir / "import_edges.tsv", import_rows)
    write_tsv(out_dir / "call_edges.tsv", call_rows)
    write_tsv(out_dir / "inherit_edges.tsv", inherits_rows)
    write_tsv(out_dir / "graph_edges.tsv", edge_rows)

    edge_counts = Counter(e["type"] for e in graph["edges"])
    file_symbol_counts = Counter()
    for n in graph["nodes"]:
        if n["type"] in {"class", "function", "method"}:
            file_symbol_counts[n["path"]] += 1
    import_targets = Counter(e["target"] for e in graph["edges"] if e["type"] == "imports")
    call_targets = Counter(e["detail"] for e in graph["edges"] if e["type"] == "calls")

    report = [
        "# LACA Code Graph Report",
        "",
        f"Version: `{graph['version']}`",
        f"Mode: `{graph['mode']}`",
        f"Scanned code files: **{graph['scanned_code_files']}** / available **{graph['available_code_files']}**",
        f"Nodes: **{len(graph['nodes'])}**",
        f"Edges: **{len(graph['edges'])}**",
        f"Cache reused: **{graph.get('cache',{}).get('reused',0)}**; parsed/changed: **{graph.get('cache',{}).get('parsed_or_changed',0)}**",
        "",
        "## Parser modes",
        "",
    ]
    for key, value in sorted(graph.get("parser_modes", {}).items()):
        report.append(f"- {key}: {value}")
    report += ["", "## Tree-sitter status", "", f"- Available: **{graph.get('tree_sitter',{}).get('available')}**", f"- Note: {graph.get('tree_sitter',{}).get('note','')}", "", "## Edge counts", ""]
    for key, value in sorted(edge_counts.items()):
        report.append(f"- {key}: {value}")
    report += ["", "## Files with most symbols", ""]
    for path, count in file_symbol_counts.most_common(20):
        report.append(f"- `{path}` — {count}")
    report += ["", "## Top import targets", ""]
    for target, count in import_targets.most_common(20):
        report.append(f"- `{target}` — {count}")
    report += ["", "## Top call targets", ""]
    for target, count in call_targets.most_common(20):
        report.append(f"- `{target}` — {count}")
    if graph.get("compiler_probe_enabled"):
        counts = Counter(r.get("status") for r in graph.get("compiler_results", []))
        report += ["", "## Compiler/syntax probe", ""]
        for k, v in sorted(counts.items()):
            report.append(f"- {k}: {v}")
        report.append("See `compiler_probe_report.md`.")
    if graph.get("errors"):
        report += ["", "## Parse/read warnings", ""]
        for err in graph["errors"][:80]:
            report.append(f"- {err}")
    report.append("")
    (out_dir / "graph_report.md").write_text("\n".join(report), encoding="utf-8")

    compiler_report = ["# LACA Compiler/Syntax Probe", "", "This is a lightweight syntax/compile probe, not full compiler-level semantic proof.", ""]
    if graph.get("compiler_results"):
        for r in graph["compiler_results"]:
            compiler_report.append(f"## {r.get('path')}")
            compiler_report.append(f"- Status: **{r.get('status')}**")
            compiler_report.append(f"- Command: `{r.get('cmd','')}`")
            if r.get("reason"):
                compiler_report.append(f"- Reason: {r.get('reason')}")
            if r.get("stderr"):
                compiler_report.append("```text")
                compiler_report.append(str(r.get("stderr"))[:2000])
                compiler_report.append("```")
            compiler_report.append("")
    else:
        compiler_report.append("Compiler probe not enabled or no supported compiler was available.")
    (out_dir / "compiler_probe_report.md").write_text("\n".join(compiler_report), encoding="utf-8")

    attention = [
        "# LACA Attention Guide",
        "",
        "This is a compact routing layer for AI agents. It is not a replacement for reading code; it tells the agent where to look first.",
        "",
        "## Read order",
        "",
        "1. `AI_OUT/current_task.md`",
        "2. `AI_OUT/action_points.tsv`",
        "3. `AI_OUT/code_symbols.tsv`",
        "4. `AI_OUT/import_edges.tsv`, `AI_OUT/call_edges.tsv`, and `AI_OUT/inherit_edges.tsv`",
        "5. Use `query_explain.md` / `path_explain.md` if present.",
        "6. Open only the files needed for the current task.",
        "",
        "## Transformer-friendly rule",
        "",
        "Do not inject the full code graph into the prompt. Use this guide and the top symbol/edge tables as an attention map.",
        "",
        "## Most symbol-dense files",
        "",
    ]
    for path, count in file_symbol_counts.most_common(12):
        attention.append(f"- `{path}` — {count} symbols")
    attention += ["", "## Strong import hubs", ""]
    for target, count in import_targets.most_common(12):
        attention.append(f"- `{target}` — {count} imports")
    attention += ["", "## Frequent call names", ""]
    for target, count in call_targets.most_common(12):
        attention.append(f"- `{target}` — {count} calls")
    attention.append("")
    (out_dir / "attention_guide.md").write_text("\n".join(attention), encoding="utf-8")

    vmem = [
        f"GRAPH|version={graph['version']}|mode={graph['mode']}|files={graph['scanned_code_files']}|nodes={len(graph['nodes'])}|edges={len(graph['edges'])}",
        f"GRAPH_CACHE|reused={graph.get('cache',{}).get('reused',0)}|parsed_or_changed={graph.get('cache',{}).get('parsed_or_changed',0)}",
        f"TREE_SITTER|available={str(graph.get('tree_sitter',{}).get('available')).upper()}|note={str(graph.get('tree_sitter',{}).get('note','')).replace('|','/')}",
        "RULE|use_graph_as_attention_map|do_not_dump_full_graph_into_prompt",
    ]
    for path, count in file_symbol_counts.most_common(20):
        vmem.append(f"GRAPH_FILE|symbols={count}|path={path}")
    for target, count in import_targets.most_common(20):
        vmem.append(f"GRAPH_IMPORT_HUB|count={count}|target={target}")
    for target, count in call_targets.most_common(20):
        vmem.append(f"GRAPH_CALL|count={count}|target={target}")
    (out_dir / "code_attention.vmem").write_text("\n".join(vmem) + "\n", encoding="utf-8")

    write_html_viewer(graph, out_dir)


def write_html_viewer(graph: dict, out_dir: Path) -> None:
    subset = {
        "summary": {"nodes": len(graph["nodes"]), "edges": len(graph["edges"]), "mode": graph["mode"], "version": graph["version"]},
        "nodes": graph["nodes"][:3000],
        "edges": graph["edges"][:6000],
    }
    graph_json = json.dumps(subset, ensure_ascii=False)
    html_text = f"""<!doctype html>
<meta charset=\"utf-8\">
<title>LACA Code Graph</title>
<style>
body{{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px;background:#111;color:#eee}}
input{{width:100%;padding:10px;background:#1e1e1e;color:#eee;border:1px solid #444;border-radius:6px;margin:8px 0 16px}}
table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border-bottom:1px solid #333;padding:6px;vertical-align:top}}code{{color:#8bd5ff}}.pill{{background:#333;border-radius:99px;padding:2px 8px}}
</style>
<h1>LACA Code Graph</h1>
<p>Version: <b>{html.escape(graph['version'])}</b>; mode: <b>{html.escape(graph['mode'])}</b>; files: <b>{graph['scanned_code_files']}</b>; nodes: <b>{len(graph['nodes'])}</b>; edges: <b>{len(graph['edges'])}</b>.</p>
<p>Search is local in this HTML subset. Full data is in <code>code_graph.json</code>.</p>
<input id=\"q\" placeholder=\"Search path, symbol, import, call...\" oninput=\"render()\">
<h2>Nodes</h2><div id=\"nodes\"></div>
<h2>Edges</h2><div id=\"edges\"></div>
<script id=\"graph-data\" type=\"application/json\">{html.escape(graph_json)}</script>
<script>
const data = JSON.parse(document.getElementById('graph-data').textContent);
function esc(s){{ return String(s??'').replace(/[&<>]/g, c=>({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[c])); }}
function table(rows, cols){{
  return '<table><thead><tr>'+cols.map(c=>'<th>'+esc(c)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+cols.map(c=>'<td>'+esc(r[c]??'')+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
}}
function render(){{
  const q = document.getElementById('q').value.toLowerCase();
  const nh = data.nodes.filter(n=>!q || [n.type,n.name,n.path,n.language,n.id].join(' ').toLowerCase().includes(q)).slice(0,200);
  const eh = data.edges.filter(e=>!q || [e.type,e.source,e.target,e.path,e.detail].join(' ').toLowerCase().includes(q)).slice(0,250);
  document.getElementById('nodes').innerHTML = table(nh, ['type','name','path','line','language']);
  document.getElementById('edges').innerHTML = table(eh, ['type','source','target','path','line','detail']);
}}
render();
</script>
"""
    (out_dir / "graph.html").write_text(html_text, encoding="utf-8")


def score_hit(text: str, q: str) -> int:
    t = text.casefold()
    qf = q.casefold()
    if t == qf:
        return 100
    if t.endswith(qf):
        return 80
    if qf in t:
        return 60
    return 0


def find_hits(graph: dict, query: str, limit: int = 100) -> list[dict[str, Any]]:
    q = query.casefold().strip()
    hits = []
    for n in graph.get("nodes", []):
        hay = " ".join([n.get("name", ""), n.get("path", ""), n.get("type", ""), n.get("id", "")])
        s = score_hit(hay, q)
        if s:
            hits.append({"kind": "node", "score": s, **n})
    for e in graph.get("edges", []):
        hay = " ".join([e.get("source", ""), e.get("target", ""), e.get("detail", ""), e.get("path", ""), e.get("type", "")])
        s = score_hit(hay, q)
        if s:
            hits.append({"kind": "edge", "score": s, **e})
    return sorted(hits, key=lambda h: h.get("score", 0), reverse=True)[:limit]


def explain_query(query: str, out_dir: Path) -> str:
    graph_path = out_dir / "code_graph.json"
    if not graph_path.exists():
        return "No code_graph.json found. Run `py AI\\run.py graph` first."
    graph = json.loads(graph_path.read_text(encoding="utf-8", errors="replace"))
    hits = find_hits(graph, query, 120)
    lines = [f"# LACA Query Explain: {query}", "", f"Hits: **{len(hits)}**", ""]
    for h in hits[:100]:
        if h["kind"] == "node":
            lines.append(f"- NODE score={h.get('score')} `{h.get('type')}` `{h.get('name')}` in `{h.get('path')}` line {h.get('line')}")
        else:
            lines.append(f"- EDGE score={h.get('score')} `{h.get('type')}` `{h.get('source')}` → `{h.get('target')}` in `{h.get('path')}` line {h.get('line')} `{h.get('detail')}`")
    result = "\n".join(lines) + "\n"
    (out_dir / "query_explain.md").write_text(result, encoding="utf-8")
    return result


def resolve_query_to_ids(graph: dict, query: str) -> list[str]:
    hits = find_hits(graph, query, 50)
    ids = []
    for h in hits:
        if h["kind"] == "node":
            ids.append(h["id"])
        else:
            ids.extend([h.get("source", ""), h.get("target", "")])
    return [x for x in dict.fromkeys(ids) if x]


def explain_path(source_query: str, target_query: str, out_dir: Path, max_depth: int = 6) -> str:
    graph_path = out_dir / "code_graph.json"
    if not graph_path.exists():
        return "No code_graph.json found. Run `py AI\\run.py graph` first."
    graph = json.loads(graph_path.read_text(encoding="utf-8", errors="replace"))
    idx = build_indexes(graph)
    starts = resolve_query_to_ids(graph, source_query)[:10]
    goals = set(resolve_query_to_ids(graph, target_query)[:20])
    lines = [f"# LACA Path Explain", "", f"From: `{source_query}`", f"To: `{target_query}`", ""]
    if not starts or not goals:
        lines += ["No start or target nodes resolved.", ""]
        result = "\n".join(lines)
        (out_dir / "path_explain.md").write_text(result, encoding="utf-8")
        return result
    queue = deque([(s, []) for s in starts])
    seen = set(starts)
    found: list[dict[str, Any]] | None = None
    while queue:
        node, path_edges = queue.popleft()
        if node in goals:
            found = path_edges
            break
        if len(path_edges) >= max_depth:
            continue
        for e in idx["adjacency"].get(node, []) + idx["reverse"].get(node, []):
            nxt = e["target"] if e["source"] == node else e["source"]
            if nxt in seen:
                continue
            seen.add(nxt)
            queue.append((nxt, path_edges + [e]))
    if found is None:
        lines += ["No short path found in the current graph subset.", ""]
    else:
        lines += [f"Found path length: **{len(found)}**", ""]
        for i, e in enumerate(found, 1):
            lines.append(f"{i}. `{e.get('source')}` --{e.get('type')}--> `{e.get('target')}` (`{e.get('path')}`:{e.get('line')}) {e.get('detail','')}")
    result = "\n".join(lines) + "\n"
    (out_dir / "path_explain.md").write_text(result, encoding="utf-8")
    return result


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="laca-code-graph", description="LACA optional AST/code graph layer")
    p.add_argument("root", nargs="?", default=".")
    p.add_argument("--out", default="AI_OUT")
    p.add_argument("--state", default="AI_STATE")
    p.add_argument("--seed-file", default="")
    p.add_argument("--full", action="store_true", help="Scan all supported code files up to --max-files")
    p.add_argument("--max-files", type=int, default=500)
    p.add_argument("--exclude-patterns", default="")
    p.add_argument("--query", default="", help="After graph build/existing graph, write query_explain.md")
    p.add_argument("--path-from", default="", help="Find graph path from this query")
    p.add_argument("--path-to", default="", help="Find graph path to this query")
    p.add_argument("--compiler-probe", action="store_true", help="Run lightweight syntax/compile probes where available")
    return p


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    root = Path(args.root)
    out_dir = Path(args.out)
    state_dir = Path(args.state)
    excludes = [x.strip() for x in args.exclude_patterns.split(",") if x.strip()]
    seed = Path(args.seed_file) if args.seed_file else None
    graph = build_graph(
        root, out_dir, state_dir, seed_file=seed, full=args.full, max_files=args.max_files,
        exclude_patterns=excludes, query=args.query, path_from=args.path_from, path_to=args.path_to,
        compiler_probe_enabled=args.compiler_probe,
    )
    print(f"LACA code graph v{VERSION}: mode={graph['mode']} files={graph['scanned_code_files']} nodes={len(graph['nodes'])} edges={len(graph['edges'])}")
    print(f"Cache reused={graph.get('cache',{}).get('reused',0)} parsed_or_changed={graph.get('cache',{}).get('parsed_or_changed',0)}")
    print(f"Wrote {out_dir / 'code_graph.json'}")
    print(f"Wrote {out_dir / 'attention_guide.md'}")
    if args.query:
        print(f"Wrote {out_dir / 'query_explain.md'}")
    if args.path_from and args.path_to:
        print(f"Wrote {out_dir / 'path_explain.md'}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

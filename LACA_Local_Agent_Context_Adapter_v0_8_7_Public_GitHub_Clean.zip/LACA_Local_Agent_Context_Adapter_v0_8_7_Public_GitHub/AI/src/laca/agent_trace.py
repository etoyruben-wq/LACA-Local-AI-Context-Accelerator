from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "0.8.7"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    if not path.exists() or not path.is_file():
        return ""
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text(path: Path, max_chars: int = 200_000) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")[:max_chars]


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def load_jsonl_tail(path: Path, limit: int = 20) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
        out = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return out
    except Exception:
        return []


def parse_vmem(path: Path) -> dict[str, list[str]]:
    data: dict[str, list[str]] = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition("|")
        key = key.strip().upper()
        value = value.strip() if sep else ""
        data.setdefault(key, []).append(value)
    return data


def first_value(data: dict[str, list[str]], key: str, default: str = "") -> str:
    vals = data.get(key.upper()) or []
    return vals[0] if vals else default


def parse_pipe_fields(line: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for part in line.split("|"):
        if "=" in part:
            k, v = part.split("=", 1)
            fields[k.strip().lower()] = v.strip()
    return fields


def task_from_result(result_data: dict[str, list[str]]) -> str:
    explicit = first_value(result_data, "TASK")
    if explicit:
        return explicit
    fields = parse_pipe_fields(first_value(result_data, "RESULT") or first_value(result_data, "STATUS"))
    return fields.get("task", "")


def status_from_result(result_data: dict[str, list[str]]) -> str:
    line = first_value(result_data, "RESULT") or first_value(result_data, "STATUS")
    fields = parse_pipe_fields(line)
    status = fields.get("status", "").upper()
    upper = (status or line).upper()
    if "PASS" in upper:
        return "PASS"
    if "BLOCK" in upper:
        return "BLOCKED"
    if "FAIL" in upper or "ERROR" in upper:
        return "FAIL"
    return "UNKNOWN"


def collect_mistakes(result_data: dict[str, list[str]], status: str) -> list[dict[str, str]]:
    mistake_keys = ["MISTAKE", "WRONG_ACTION", "ERROR", "BLOCKER"]
    lessons = result_data.get("LESSON", [])
    lesson_text = lessons[-1] if lessons else ""
    mistakes: list[dict[str, str]] = []
    for key in mistake_keys:
        for value in result_data.get(key, []):
            mistakes.append({"type": key, "description": value, "lesson": lesson_text})
    if status in {"FAIL", "BLOCKED"} and not mistakes:
        evidence = "; ".join(result_data.get("EVIDENCE", [])[:3])
        next_step = "; ".join(result_data.get("NEXT", [])[:3])
        mistakes.append({
            "type": status,
            "description": evidence or "Result did not pass; inspect RESULT.vmem evidence.",
            "lesson": lesson_text or next_step or "Do not repeat the failed path; inspect latest action points and context first.",
        })
    return mistakes


def current_stamp_id() -> str:
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")[:-3]


def hashes(out_dir: Path, state_dir: Path, result_file: Path) -> dict[str, str]:
    return {
        "result_sha256": sha256_file(result_file),
        "context_state_sha256": sha256_file(out_dir / "context_state.vmem"),
        "action_points_sha256": sha256_file(out_dir / "action_points.tsv"),
        "code_graph_sha256": sha256_file(out_dir / "code_graph.json"),
        "project_map_sha256": sha256_file(state_dir / "project_map.json"),
        "task_state_sha256": sha256_file(state_dir / "task_state.json"),
    }


def record_agent_stamp(result_file: Path, out_dir: Path, state_dir: Path, project_root: Path | None = None) -> dict[str, Any]:
    """Record an Agent Trace Stamp after an AI/coding-agent action.

    Public term: Agent Trace Stamp.
    Internal Ukrainian nickname: "печатка трансформатора".
    It records what the agent did, what files changed, what failed, and what should not be repeated.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    state_dir.mkdir(parents=True, exist_ok=True)
    result_data = parse_vmem(result_file)
    status = status_from_result(result_data)
    stamp_id = current_stamp_id()
    record: dict[str, Any] = {
        "version": VERSION,
        "stamp_id": stamp_id,
        "time": time.time(),
        "utc": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "project_root": str(project_root) if project_root else "",
        "source": str(result_file),
        "status": status,
        "task": task_from_result(result_data),
        "result": first_value(result_data, "RESULT") or first_value(result_data, "STATUS"),
        "changed": result_data.get("CHANGED", []),
        "files_read": result_data.get("FILES_READ", []),
        "files_changed": result_data.get("FILES_CHANGED", []) or result_data.get("CHANGED", []),
        "evidence": result_data.get("EVIDENCE", []),
        "next": result_data.get("NEXT", []),
        "mistakes": collect_mistakes(result_data, status),
        "hashes": hashes(out_dir, state_dir, result_file),
    }
    append_jsonl(state_dir / "agent_trace.jsonl", record)
    append_jsonl(state_dir / "transformer_stamp.jsonl", record)
    append_jsonl(out_dir / "agent_trace.jsonl", record)

    for m in record["mistakes"]:
        mistake_record = {
            "version": VERSION,
            "stamp_id": stamp_id,
            "time": record["time"],
            "status": status,
            "mistake": m,
            "source": str(result_file),
            "task": record.get("task", ""),
            "next": record.get("next", []),
        }
        append_jsonl(state_dir / "mistake_memory.jsonl", mistake_record)
        append_jsonl(out_dir / "mistake_memory.jsonl", mistake_record)

    write_trace_reports(out_dir, state_dir)
    return record


def write_trace_reports(out_dir: Path, state_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    trace = load_jsonl_tail(state_dir / "agent_trace.jsonl", 20)
    mistakes = load_jsonl_tail(state_dir / "mistake_memory.jsonl", 30)
    latest = trace[-1] if trace else {}

    lines = [
        "# Last Agent Trace Stamp",
        "",
        "Agent Trace Stamp is a small action ledger for AI coding agents. It helps the next run avoid repeating already failed actions.",
        "",
    ]
    if latest:
        lines += [
            f"- Stamp ID: `{latest.get('stamp_id','')}`",
            f"- Status: **{latest.get('status','UNKNOWN')}**",
            f"- Task: `{latest.get('task','')}`",
            f"- Result: `{latest.get('result','')}`",
            f"- Changed: `{latest.get('changed', [])}`",
            f"- Next: `{latest.get('next', [])}`",
            "",
            "## Do not repeat / Mistakes",
            "",
        ]
        if latest.get("mistakes"):
            for m in latest.get("mistakes", []):
                lines.append(f"- **{m.get('type','MISTAKE')}**: {m.get('description','')}; lesson: {m.get('lesson','')}")
        else:
            lines.append("- No mistake recorded for the latest stamp.")
    else:
        lines.append("No agent stamp has been recorded yet. After an action, create RESULT.vmem and run `py AI\\run.py result`.")
    (out_dir / "last_transformer_stamp.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    trace_report = ["# Agent Trace Report", "", f"Recent stamps: **{len(trace)}**", ""]
    for item in reversed(trace[-10:]):
        trace_report.append(f"- `{item.get('stamp_id','')}` — **{item.get('status','UNKNOWN')}** — task `{item.get('task','')}` — changed `{item.get('changed', [])}`")
    trace_report.append("")
    trace_report.append("Next run should read this together with `context_state.vmem`, `action_points.tsv`, and `code_graph.json`.")
    (out_dir / "agent_trace_report.md").write_text("\n".join(trace_report) + "\n", encoding="utf-8")

    mistake_report = ["# Mistake Memory", "", f"Recorded mistakes/blockers: **{len(mistakes)}**", ""]
    if mistakes:
        for item in reversed(mistakes[-15:]):
            m = item.get("mistake", {})
            mistake_report.append(f"- `{item.get('stamp_id','')}` — **{m.get('type','MISTAKE')}**: {m.get('description','')}; lesson: {m.get('lesson','')}")
    else:
        mistake_report.append("No mistakes recorded yet.")
    mistake_report.append("")
    mistake_report.append("Rule: do not repeat a recorded failed action unless the user explicitly asks to retry it with changed conditions.")
    (out_dir / "mistake_report.md").write_text("\n".join(mistake_report) + "\n", encoding="utf-8")


def trace_summary_lines(state_dir: Path, max_mistakes: int = 3) -> list[str]:
    trace = load_jsonl_tail(state_dir / "agent_trace.jsonl", 5)
    mistakes = load_jsonl_tail(state_dir / "mistake_memory.jsonl", max_mistakes)
    lines: list[str] = []
    if trace:
        last = trace[-1]
        lines.append(f"STAMP|last_id={last.get('stamp_id','')}|status={last.get('status','UNKNOWN')}|result={str(last.get('result','')).replace('|','/')}")
        next_items = last.get("next", []) or []
        if next_items:
            lines.append(f"STAMP_NEXT|{str(next_items[0]).replace('|','/')}")
    else:
        lines.append("STAMP|last_id=none|status=NONE|result=no_previous_agent_stamp")
    if mistakes:
        for mrec in mistakes[-max_mistakes:]:
            m = mrec.get("mistake", {})
            desc = str(m.get("description", "")).replace("|", "/")[:180]
            lesson = str(m.get("lesson", "")).replace("|", "/")[:180]
            lines.append(f"MISTAKE_MEMORY|type={m.get('type','MISTAKE')}|description={desc}|lesson={lesson}")
    else:
        lines.append("MISTAKE_MEMORY|none")
    lines.append("RULE|read_last_transformer_stamp_md|avoid_repeating_recorded_mistakes")
    return lines

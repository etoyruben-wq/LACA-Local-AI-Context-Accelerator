# LACA Graph Query / Path / Explain Layer

v0.8.3 adds a practical query layer over `code_graph.json`.

## Query

```bat
py AI\run.py graph --query "SomeClass"
```

Writes:

```text
AI_OUT/query_explain.md
```

The query searches file paths, symbol names, import targets, call names, and graph edge details. Unicode/Cyrillic identifiers and paths are supported through Python's Unicode strings and casefold comparison.

## Path explain

```bat
py AI\run.py graph --path-from "entry" --path-to "target"
```

Writes:

```text
AI_OUT/path_explain.md
```

This tries to find a short connection through the current graph subset. If no path is found, the agent should expand the graph with `--full --max-files N` or use a more precise query.

## Limits

This is an agent-routing graph, not a formal compiler proof. It is intended to tell the model where to look first.

# GitHub description

LACA — Local Agent Context Adapter is an agent-independent project memory harness for AI coding agents. It keeps a persistent local project map, task file, code graph, action history, mistake memory, and Skill Protocol so agents can continue work without starting from zero.

## Suggested short description

Agent-independent project memory harness for AI coding agents: project map, task file, code graph, action history, mistake memory, and Skill Protocol.

## Suggested topics

```text
ai
ai-agent
coding-agent
local-ai
context-engineering
project-memory
code-graph
agent-memory
software-engineering
codex
cursor
antigravity
```

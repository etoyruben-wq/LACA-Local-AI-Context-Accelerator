# Installation

1. Download or clone this repository.
2. Copy the `AI` folder into the root of the project you want an AI agent to work on.
3. Edit `AI/TASK.md` or `AI/ТЗ_UA.md`.
4. Ask the agent to follow the instruction in the `AI` folder.

No global installation is required. LACA is designed as a drop-in project folder.

## Windows

```bat
py AI\run.py scan
py AI\run.py continue
py AI\run.py graph
py AI\run.py skill
```

## Python fallback

If `py` is not available:

```bat
python AI\run.py scan
python AI\run.py continue
```

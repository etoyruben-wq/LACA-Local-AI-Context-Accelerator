# Release notes — LACA v0.8.7 Public GitHub Clean

This release prepares LACA for GitHub publication without the planned multi-agent coordinator.

## Included

- Drop-in `AI` folder.
- Persistent project map.
- Task files: `AI/TASK.md` and `AI/ТЗ_UA.md`.
- BM25F-style ranking.
- Unicode/Cyrillic tokenization.
- Python AST code graph.
- Query/path/explain basics.
- Agent Trace Stamp.
- Mistake memory.
- Public Skill Protocol.
- Codex/Antigravity/Cursor/generic agent instruction files.

## Not included

- Multi-agent parallel coordinator.
- Private vector architecture guard.
- Private accelerators.
- Private project-specific logic.
- Android companion module.

## Positioning

LACA is an agent-independent project memory harness, not a chatbot and not a replacement for an AI coding agent.

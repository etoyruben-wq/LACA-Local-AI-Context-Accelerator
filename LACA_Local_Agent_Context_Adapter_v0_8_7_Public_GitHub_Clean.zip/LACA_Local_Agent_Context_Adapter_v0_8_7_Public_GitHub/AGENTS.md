# AGENTS.md — LACA repository instructions

When working on this repository, preserve the public scope of LACA.

## Rules

- Do not add private project-specific architecture details.
- Do not add multi-agent parallel coordination in this public clean release.
- Keep the package drop-in: users copy the `AI` folder into a project.
- Keep user-facing workflow simple.
- Preserve Unicode/Cyrillic support.
- Keep Skill Protocol generic and agent-independent.
- Update `AI/CHANGELOG.md` and `README.md` when changing behavior.

## Test commands

```bat
py AI\run.py status
py AI\run.py scan
py AI\run.py continue
py AI\run.py graph
py AI\run.py skill
```

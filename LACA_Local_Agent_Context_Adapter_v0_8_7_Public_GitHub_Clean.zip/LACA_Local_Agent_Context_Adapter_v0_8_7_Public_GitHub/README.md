# LACA — Local Agent Context Adapter

**Version:** 0.8.7 public GitHub clean release  
**Author:** Ruben Galstyn / Galstyn Ruben Smbatovych

LACA is an agent-independent project memory harness for AI coding agents.

It gives AI agents a persistent local project map, task file, code graph, action points, result history, Agent Trace Stamp, mistake memory, and a public Skill Protocol so the agent does not need to rediscover the project from zero every session.

This public release does **not** include private project-specific architecture guards, private accelerators, or multi-agent coordination. The multi-agent coordinator is intentionally deferred to a later release.

## What LACA does

- Creates a persistent project map in `AI_STATE/project_map.json`.
- Reads a user task file from `AI/TASK.md` or `AI/ТЗ_UA.md`.
- Generates compact agent context in `AI_OUT/context_state.vmem`.
- Generates action points in `AI_OUT/action_points.tsv`.
- Builds a basic code graph with functions, classes, imports, calls, and inheritance.
- Records previous actions through Agent Trace Stamp.
- Records important mistakes so future agents do not repeat them.
- Provides a public Skill Protocol for Codex-style, Antigravity-style, Cursor-style, and generic agents.

## Quick start

Copy the `AI` folder into the root of your project:

```text
MyProject/
  AI/
  src/
  README.md
```

First run prompt for an AI agent:

```text
There is an AI folder in the project root. Open it and follow the instruction inside.
```

Ukrainian:

```text
У папці проєкту є папка AI. В папці є інструкція. Виконай інструкцію.
```

Continue prompt:

```text
There is an AI folder in the project root. There is a CONTINUE instruction. Execute it.
```

Ukrainian:

```text
У папці проєкту є папка AI. Там є інструкція ПРОДОВЖИТИ. Виконай.
```

## Manual commands

First scan:

```bat
py AI\run.py scan
```

Continue from saved project memory:

```bat
py AI\run.py continue
```

Build or update code graph:

```bat
py AI\run.py graph
```

Generate Skill Protocol context:

```bat
py AI\run.py skill
```

After an agent action, create `RESULT.vmem`, then run:

```bat
py AI\run.py result
```

## Main generated outputs

```text
AI_OUT/context_state.vmem
AI_OUT/action_points.tsv
AI_OUT/context_report.md
AI_OUT/current_task.md
AI_OUT/code_graph.json
AI_OUT/graph_report.md
AI_OUT/graph.html
AI_OUT/last_transformer_stamp.md
AI_OUT/mistake_report.md
AI_OUT/skill_protocol_context.md
```

Persistent state:

```text
AI_STATE/project_map.json
AI_STATE/change_log.jsonl
AI_STATE/result_history.jsonl
AI_STATE/agent_trace.jsonl
AI_STATE/mistake_memory.jsonl
```

## Core positioning

Graph tools map the codebase.

LACA maps the codebase, the task, previous agent actions, and known mistakes.

```text
LACA = project map + task + code graph + agent trace + mistake memory + skill protocol
```

## Public scope

This public release is intentionally neutral. It asks agents to preserve the project’s native architecture and avoid unrelated rewrites, but it does not include private architecture-specific rules.

Multi-agent parallel coordination is not included in this package. It is planned as a later module.

## License

Licensed under the PolyForm Noncommercial License 1.0.0. Commercial use requires separate written permission from the author.
